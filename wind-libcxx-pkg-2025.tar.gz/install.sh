#!/usr/bin/env bash
set -e

TARGET="/opt/libcxx-pkgs"
echo "安装到 $TARGET"

sudo mkdir -p $TARGET
sudo cp -a pkgs/* $TARGET/
sudo chown -R $USER:$USER $TARGET 2>/dev/null || true
sudo chmod +x $TARGET/bin/protoc 2>/dev/null || true

# 环境变量（只添加一次）
if ! grep -q "libcxx-pkgs" ~/.bashrc; then
    cat >> ~/.bashrc <<'EOS'

# libc++ 环境（Protobuf 34 + Abseil LTS 静态）
export PATH="/opt/libcxx-pkgs/bin:$PATH"
export CMAKE_PREFIX_PATH="/opt/libcxx-pkgs:$CMAKE_PREFIX_PATH"
EOS
fi

echo "安装完成。请执行：source ~/.bashrc  或重启终端"
/opt/libcxx-pkgs/bin/protoc --version 2>/dev/null || true
