#!/usr/bin/env bash
set -e

echo "===================================================="
echo "  Wind 纯 libc++ 豪华套装 2025 一键安装" (这AI写的, 我语气没这么夸张)
echo "  包含 Protobuf 34.0.0 + 静态 Abseil LTS + Clang 21 生态"
echo "===================================================="

TARGET="/opt/libcxx-pkgs"
sudo mkdir -p "$TARGET"
sudo cp -a pkgs/* "$TARGET/"

# 修复权限
sudo chown -R "$USER":"$USER" "$TARGET" 2>/dev/null || true
sudo chmod +x "$TARGET/bin/protoc"* 2>/dev/null || true

# 环境变量（只加一次）
if ! grep -q "wind-libcxx-pkg-2025" "$HOME/.bashrc" 2>/dev/null; then
    cat >> "$HOME/.bashrc" <<'EOS'

# ============= Wind 纯 libc++ 豪华套装 2025 =============
export PATH="/opt/libcxx-pkgs/bin:$PATH"
export CMAKE_PREFIX_PATH="/opt/libcxx-pkgs:$CMAKE_PREFIX_PATH"
# export LD_LIBRARY_PATH="/opt/libcxx-pkgs/lib:$LD_LIBRARY_PATH"   # 一般不需要
echo "Wind 豪华套装已加载（$(/opt/libcxx-pkgs/bin/protoc --version 2>/dev/null || echo 未知)）"
EOS
fi

echo "安装完成！请执行：source ~/.bashrc  或直接重开终端"
echo "之后所有项目只需：cmake .. -G Ninja && ninja"
