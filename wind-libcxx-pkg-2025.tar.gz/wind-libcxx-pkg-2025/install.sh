#!/usr/bin/env bash
set -e

echo "===================================================="
echo "  使用 LLVM 工具链的 Protobuf 安装脚本"
echo "  包含 Protobuf 34.0.0 + Abseil（静态）+ Clang 21 工具链"
echo "===================================================="

TARGET="/opt/libcxx-pkgs"
sudo mkdir -p "$TARGET"
sudo cp -a pkgs/* "$TARGET/"

# 修正权限
sudo chown -R "$USER":"$USER" "$TARGET" 2>/dev/null || true
sudo chmod +x "$TARGET/bin/protoc"* 2>/dev/null || true

echo "安装完成。安装前缀为：$TARGET"
echo "如需使用，请手动将以下目录加入环境变量："
echo "  PATH:               $TARGET/bin"
echo "  CMAKE_PREFIX_PATH:  $TARGET"
echo ""
echo "之后可正常执行：cmake .. -G Ninja && ninja"

