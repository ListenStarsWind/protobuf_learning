#!/usr/bin/env bash
set -e

echo "===================================================="
echo "  使用 LLVM 工具链的 Protobuf 安装脚本"
echo "  包含 Protobuf 34.0.0 + Abseil（静态）+ Clang 21 工具链"
echo "===================================================="

TARGET="/opt/libcxx-pkgs"
sudo mkdir -p "$TARGET"
sudo cp -a pkgs/* "$TARGET/"

# 修正权限
sudo chown -R "$USER":"$USER" "$TARGET" 2>/dev/null || true
sudo chmod +x "$TARGET/bin/protoc"* 2>/dev/null || true

# 追加环境变量（如果之前没添加过）
if ! grep -q "wind-libcxx-pkg-2025" "$HOME/.bashrc" 2>/dev/null; then
    cat >> "$HOME/.bashrc" <<'EOS'

# ====== Wind libc++ 工具包 2025 ======
export PATH="/opt/libcxx-pkgs/bin:$PATH"
export CMAKE_PREFIX_PATH="/opt/libcxx-pkgs:$CMAKE_PREFIX_PATH"
# export LD_LIBRARY_PATH="/opt/libcxx-pkgs/lib:$LD_LIBRARY_PATH"   # 一般不用设置
echo "Wind libc++ 工具包已加载（$(/opt/libcxx-pkgs/bin/protoc --version 2>/dev/null || echo 未知)）"
EOS
fi

echo "安装完成。请执行：source ~/.bashrc  或重新打开终端"
echo "之后编译项目可直接：cmake .. -G Ninja && ninja"

